class ActivityDomain:
    """"""

    unknown = "0"

    work = "1"

    personal = "2"

    unrestricted = "3"
