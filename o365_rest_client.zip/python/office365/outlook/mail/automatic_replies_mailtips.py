from office365.runtime.client_value import ClientValue


class AutomaticRepliesMailTips(ClientValue):
    """MailTips about any automatic replies that have been set up on a mailbox."""
