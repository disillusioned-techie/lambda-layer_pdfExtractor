from office365.outlook.mail.location import Location


class LocationConstraintItem(Location):
    """The conditions stated by a client for the location of a meeting."""
