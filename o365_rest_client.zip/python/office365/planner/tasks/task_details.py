from office365.entity import Entity


class PlannerTaskDetails(Entity):
    """
    The plannerTaskDetails resource represents the additional information about a task.
    Each task object has a details object.
    """

    pass
