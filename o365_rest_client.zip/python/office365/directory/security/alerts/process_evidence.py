from office365.directory.security.alerts.evidence import AlertEvidence


class ProcessEvidence(AlertEvidence):
    """Represents a process that is reported in the alert as evidence."""
