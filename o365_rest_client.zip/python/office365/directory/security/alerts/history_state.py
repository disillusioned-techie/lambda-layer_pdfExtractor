from office365.runtime.client_value import ClientValue


class AlertHistoryState(ClientValue):
    """Stores changes made to alerts."""
