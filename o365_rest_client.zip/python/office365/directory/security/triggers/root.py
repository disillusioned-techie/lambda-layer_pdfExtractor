from office365.entity import Entity


class TriggersRoot(Entity):
    """"""

    @property
    def entity_type_name(self):
        return "microsoft.graph.security.triggersRoot"
