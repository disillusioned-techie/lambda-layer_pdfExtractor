from office365.runtime.client_value import ClientValue


class AttackSimulationUser(ClientValue):
    """Represents a user in an attack simulation and training campaign."""
