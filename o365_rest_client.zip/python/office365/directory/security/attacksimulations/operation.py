from office365.onedrive.operations.long_running import LongRunningOperation


class AttackSimulationOperation(LongRunningOperation):
    """Represents the status of a long-running attack simulation training operation."""
