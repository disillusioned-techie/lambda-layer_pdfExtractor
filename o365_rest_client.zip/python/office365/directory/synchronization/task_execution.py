from office365.runtime.client_value import ClientValue


class SynchronizationTaskExecution(ClientValue):
    """Summarizes the results of the synchronization job run."""
