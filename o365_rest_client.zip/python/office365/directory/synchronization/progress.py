from office365.runtime.client_value import ClientValue


class SynchronizationProgress(ClientValue):
    """Represents the progress of a synchronizationJob toward completion."""
