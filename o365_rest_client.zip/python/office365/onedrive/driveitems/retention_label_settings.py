from office365.runtime.client_value import ClientValue


class RetentionLabelSettings(ClientValue):
    """
    Groups all the compliance retention restrictions on the item into a single structure.
    """
